# Action Classification Docker Solution

## Сборка Docker образа
```bash
docker build -t action-classifier .
```

## Запуск
```bash
docker run --rm -v /path/to/folder:/data action-classifier /data
```

## Требования
- Папка должна содержать ровно 8 изображений (.jpg или .png)
- Docker должен быть установлен

## Результат
Программа выведет один из трёх классов: inaction, move, work
