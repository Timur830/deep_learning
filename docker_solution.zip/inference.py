import torch
import torch.nn as nn
from torchvision.models import mobilenet_v3_small, MobileNet_V3_Small_Weights
import cv2
import numpy as np
from pathlib import Path
import albumentations as A
import json
import argparse
import sys

# ============================================
# АРХИТЕКТУРА МОДЕЛИ
# ============================================
class ActionClassifier(nn.Module):
    def __init__(self, num_classes=3, sequence_length=8, dropout_rate=0.3):
        super().__init__()
        
        backbone = mobilenet_v3_small(weights=MobileNet_V3_Small_Weights.IMAGENET1K_V1)
        self.feature_extractor = nn.Sequential(*list(backbone.children())[:-1])
        
        self.projection = nn.Linear(576, 256)
        self.pos_encoding = nn.Parameter(torch.randn(1, sequence_length, 256))
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=256, nhead=8, dim_feedforward=512,
            dropout=dropout_rate, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2)
        
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(dropout_rate * 0.5),
            nn.Linear(64, num_classes)
        )
        
    def forward(self, x):
        batch_size, seq_len, c, h, w = x.shape
        
        x = x.view(batch_size * seq_len, c, h, w)
        features = self.feature_extractor(x)
        features = features.view(batch_size, seq_len, -1)
        
        features = self.projection(features)
        features = features + self.pos_encoding
        features = self.transformer(features)
        features = features.mean(dim=1)
        
        return self.classifier(features)

# ============================================
# ФУНКЦИИ ДЛЯ ИНФЕРЕНСА
# ============================================
def load_model(model_path, device):
    checkpoint = torch.load(model_path, map_location=device)
    
    model = ActionClassifier(
        num_classes=len(checkpoint['classes']),
        sequence_length=checkpoint['sequence_length'],
        dropout_rate=checkpoint.get('dropout_rate', 0.3)
    )
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(device)
    model.eval()
    
    return model, checkpoint['classes']

def preprocess_images(folder_path, config):
    # Ищем изображения
    image_files = sorted(list(Path(folder_path).glob('*.jpg')) + 
                        list(Path(folder_path).glob('*.png')))
    
    if len(image_files) != config['sequence_length']:
        raise ValueError(f"Expected {config['sequence_length']} images, found {len(image_files)}")
    
    # Трансформации
    transform = A.Compose([
        A.Resize(config['input_size'], config['input_size']),
        A.Normalize(mean=config['mean'], std=config['std']),
    ])
    
    frames = []
    for img_path in image_files:
        img = cv2.imread(str(img_path))
        if img is None:
            raise ValueError(f"Could not read image: {img_path}")
        
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        transformed = transform(image=img)
        frames.append(transformed['image'])
    
    # Конвертируем в тензор
    frames = np.stack(frames).transpose(0, 3, 1, 2)
    frames = torch.FloatTensor(frames).unsqueeze(0)  # (1, T, C, H, W)
    
    return frames

def predict(image_folder, model_path='model_for_inference.pth', config_path='model_config.json'):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Загружаем модель
    model, classes = load_model(model_path, device)
    
    # Загружаем конфиг
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    # Предобработка
    input_tensor = preprocess_images(image_folder, config)
    input_tensor = input_tensor.to(device)
    
    # Инференс
    with torch.no_grad():
        outputs = model(input_tensor)
        predicted_class = torch.argmax(outputs, dim=1).item()
    
    return classes[predicted_class]

def main():
    parser = argparse.ArgumentParser(description='Action classification from 8 frames')
    parser.add_argument('folder_path', type=str, 
                       help='Path to folder containing exactly 8 images')
    parser.add_argument('--model', type=str, default='model_for_inference.pth',
                       help='Path to model file')
    parser.add_argument('--config', type=str, default='model_config.json',
                       help='Path to config file')
    
    args = parser.parse_args()
    
    try:
        result = predict(args.folder_path, args.model, args.config)
        print(result)
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()